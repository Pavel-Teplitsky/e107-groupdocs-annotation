<?php
define("GDALAN_01", "Lets you annotate on PPT, PPTX, XLS, XLSX, DOC, DOCX, PDF and many other formats from your GroupDocs acount in a web page using the GroupDocs Annotation (no Flash or PDF browser plug-ins required).");
define("GDALAN_02", "Settings");
define("GDALAN_03", "Installation Successful...");
define("GDALAN_04", "Upgrade successful...");
define("GDALAN_05", "Save Changes");
define("GDALAN_06", "Changes were saved successfully.");
define("GDALAN_07", "Error: please fill all inputs!");
?>